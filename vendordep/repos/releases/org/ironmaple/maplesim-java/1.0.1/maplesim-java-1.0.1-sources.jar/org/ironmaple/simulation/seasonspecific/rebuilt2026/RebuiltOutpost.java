package org.ironmaple.simulation.seasonspecific.rebuilt2026;

import static edu.wpi.first.units.Units.Centimeters;
import static edu.wpi.first.units.Units.Degrees;
import static edu.wpi.first.units.Units.Inches;
import static edu.wpi.first.units.Units.Meters;
import static edu.wpi.first.units.Units.MetersPerSecond;

import edu.wpi.first.math.geometry.*;
import edu.wpi.first.networktables.NetworkTableInstance;
import edu.wpi.first.networktables.StructPublisher;
import edu.wpi.first.units.measure.Angle;
import edu.wpi.first.units.measure.LinearVelocity;
import java.util.*;
import org.ironmaple.simulation.Arena;
import org.ironmaple.simulation.Goal;

/**
 *
 *
 * <h2>Simulates a <strong>OUTPOST</strong>s on the field.</h2>
 *
 * <p>This class simulates a outpost on the field where fuel can be scored. It has a store of fuel which can be added
 * too by scoring in it. This fuel can then be dumped via {@link #dump()} or
 * {@link Arena2026Rebuilt#outpostDump(boolean)}, thrown at the goal via {@link #throwForGoal()} or
 * {@link Arena2026Rebuilt#outpostThrowForGoal(boolean)}, or thrown with specific parameters via
 * {@link #throwFuel(Rotation2d, Angle, LinearVelocity)} or {@link Arena2026Rebuilt#outpostThrow(boolean, Rotation2d,
 * Angle, LinearVelocity)},
 */
public class RebuiltOutpost extends Goal {

    protected static final Translation3d redOutpostPose = new Translation3d(16.621, 7.403338, 0);
    protected static final Translation3d redLaunchPose = new Translation3d(16, 8.2, 0);
    protected static final Translation3d redDumpPose = new Translation3d(16.421, 7.2, 0);

    protected static final Translation3d blueOutpostPose = new Translation3d(0, 0.665988, 0);
    protected static final Translation3d blueDumpPose = new Translation3d(0.2, 0.665988, 0);
    protected static final Translation3d blueLaunchPose = new Translation3d(0.665988, -0.254, 0);

    protected static final Translation3d redRenderPose = new Translation3d(16.640988, 7.7, 0.844502);
    protected static final Translation3d blueRenderPose = new Translation3d(-0.12, 0.325, 0.844502);

    StructPublisher<Pose3d> posePublisher;

    protected Arena arena;

    /**
     *
     *
     * <h2>Creates an outpost of the specified color.</h2>
     *
     * @param arena The host arena of this outpost.
     * @param isBlue Wether this is the blue outpost or the red one.
     */
    public RebuiltOutpost(Arena arena, boolean isBlue) {
        super(
                arena,
                Centimeters.of(3),
                Inches.of(21),
                Centimeters.of(10),
                "Fuel",
                isBlue ? blueOutpostPose : redOutpostPose,
                isBlue,
                true);

        this.arena = arena;
        gamePieceCount = 24;

        StructPublisher<Pose3d> OutpostPublisher = NetworkTableInstance.getDefault()
                .getStructTopic(isBlue ? "BlueOutpost" : "RedOutpost", Pose3d.struct)
                .publish();

        StructPublisher<Pose3d> OutpostThrowPublisher = NetworkTableInstance.getDefault()
                .getStructTopic(isBlue ? "BlueOutpostThrow" : "RedOutpostThrow", Pose3d.struct)
                .publish();
        StructPublisher<Pose3d> OutpostDumpPublisher = NetworkTableInstance.getDefault()
                .getStructTopic(isBlue ? "BlueOutpostDump" : "RedOutpostDump", Pose3d.struct)
                .publish();

        OutpostPublisher.set(new Pose3d(position, new Rotation3d()));
        OutpostDumpPublisher.set(new Pose3d(isBlue ? blueDumpPose : redDumpPose, new Rotation3d()));
        OutpostThrowPublisher.set(new Pose3d(isBlue ? blueLaunchPose : redLaunchPose, new Rotation3d()));

        // Register with game piece manager for unified rendering
        arena.registerGamePieceVisualizationSource("Fuel", this::draw);
    }

    @Override
    protected void addPoints() {
        arena.addValueToMatchBreakdown(isBlue, "TotalFuelInOutpost", 1);
        this.gamePieceCount++;
    }

    @Override
    public void simulationSubTick(int subTickNum) {
        super.simulationSubTick(subTickNum);
        arena.replaceValueInMatchBreakDown(isBlue, "CurrentFuelInOutpost", gamePieceCount);
    }

    @Override
    public void draw(List<Pose3d> drawList) {

        int count = 0;
        for (int col = 0; col < 5 && count < gamePieceCount; col++) {
            for (int row = 0; row < 5 && count < gamePieceCount; row++) {
                count++;
                if (isBlue) {
                    drawList.add(new Pose3d(
                            blueRenderPose.plus(
                                    new Translation3d(Inches.of(-6 * col), Inches.of(6 * row), Inches.of(1.3 * col))),
                            new Rotation3d()));
                } else {
                    drawList.add(new Pose3d(
                            redRenderPose.plus(
                                    new Translation3d(Inches.of(6 * col), Inches.of(-6 * row), Inches.of(1.3 * col))),
                            new Rotation3d()));
                }
            }
        }
    }

    /** <he>Resets the outposts internal fuel counter too 24.</h2> */
    public void reset() {
        gamePieceCount = 24;
    }

    /**
     *
     *
     * <h2>Attempts too throw a game piece at the specified goal.</h2>
     *
     * <p>This method comes with variance built in (to simulate human inconsistency) and will therefore only hit about
     * half the time. Additionally if the hub does not have game pieces stored this method will not do anything. If you
     * would like to manually control how the human player throws game pieces use {@link #outpostThrow(boolean,
     * Rotation2d, Angle, LinearVelocity)}
     */
    public void throwForGoal() {
        throwFuel(
                isBlue ? Rotation2d.fromDegrees(45) : Rotation2d.fromDegrees(220),
                Degrees.of(75),
                MetersPerSecond.of(11.2));
    }

    /**
     *
     *
     * <h2>Dumps game pieces from the specified outpost.</h2>
     *
     * This function will dump up to 24 game pieces, dependent on how many game pieces are currently stored in the
     * outpost. For more manual control of the game pieces in the outpost use {@link #outpostThrow(boolean, Rotation2d,
     * Angle, LinearVelocity)}. To have a human player attempt to throw a game piece into the hub use
     * {@link #outpostThrowForGoal(boolean)}.
     */
    public void dump() {
        for (int i = 0; i < 24 && gamePieceCount > 0; i++) {
            gamePieceCount--;
            addPieceWithVariance(
                    isBlue ? blueDumpPose.toTranslation2d() : redDumpPose.toTranslation2d(),
                    new Rotation2d(),
                    Meters.of(1.7),
                    isBlue ? MetersPerSecond.of(2) : MetersPerSecond.of(-2),
                    Degrees.of(0),
                    0,
                    0.2,
                    5,
                    0.2,
                    5.0);
        }
    }

    /**
     *
     *
     * <h2>Throws a game piece from the outpost at the specified angle and speed. </h2>
     *
     * <p>This method comes with variance built in (to simulate human inconsistency). Additionally if the hub does not
     * have game pieces stored this method will not do anything. If you would like to have the human player throw at the
     * hub use {@link #outpostThrowForGoal(boolean)}
     *
     * @param throwYaw The yaw at which too throw the ball.
     * @param throwPitch The pitch at which too throw the ball.
     */
    public void throwFuel(Rotation2d yaw, Angle pitch, LinearVelocity speed) {
        if (gamePieceCount > 0) {
            gamePieceCount--;
            addPieceWithVariance(
                    isBlue ? blueLaunchPose.toTranslation2d() : redLaunchPose.toTranslation2d(),
                    yaw,
                    Meters.of(1.7),
                    speed,
                    pitch,
                    0,
                    0,
                    15,
                    2,
                    5);
        }
    }

    private void addPieceWithVariance(
            Translation2d piecePose,
            Rotation2d yaw,
            edu.wpi.first.units.measure.Distance height,
            LinearVelocity speed,
            Angle pitch,
            double xVariance,
            double yVariance,
            double yawVariance,
            double speedVariance,
            double pitchVariance) {
        var projectile = new RebuiltFuelOnFly(
                piecePose.plus(new Translation2d(randomInRange(xVariance), randomInRange(yVariance))),
                new Translation2d(),
                new edu.wpi.first.math.kinematics.ChassisSpeeds(),
                yaw.plus(Rotation2d.fromDegrees(randomInRange(yawVariance))),
                height,
                speed.plus(MetersPerSecond.of(randomInRange(speedVariance))),
                Degrees.of(pitch.in(Degrees) + randomInRange(pitchVariance)));
        this.arena.addGamePieceProjectile(projectile);
    }

    private static double randomInRange(double variance) {
        return (Math.random() - 0.5) * variance;
    }
}
